package com.springpeople.services;

//if there is no reusable code which can shared to child classes, then
//better go with interfaces.

//so you can achieve the multiple inheritance.

//all methods are abstarct
public interface VehicleInterface {

	public void sample();
}


class sampleChild implements VehicleInterface{

	@Override
	public void sample() {
		// TODO Auto-generated method stub
		
	}
	
}

class SampleChild1 implements VehicleInterface {
	@Override
	public void sample() {
		// TODO Auto-generated method stub
		
	}
}