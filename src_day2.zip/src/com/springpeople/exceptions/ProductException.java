package com.springpeople.exceptions;

public class ProductException extends Exception{

	public ProductException (String message) {
		this.message = message;
	}
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
