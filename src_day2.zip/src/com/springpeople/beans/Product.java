package com.springpeople.beans;

import java.io.Serializable;

//Java Beans..
//POJO classes

//OOPS -> Object Oriented Programming 
//100% OOP

//1. OOPS concept -> Data Hiding
//2 OOPS Concept 2: Encapsulation

//wrapping of data and functions (method) together into a 
//single unit is called encapsulation


public class Product implements Serializable {
	
	//Product p = new Product();
	public Product(){
		//BL will be executed at the time of creating objcet
		// initialisation logic
		productId = 100;
		System.out.println("product constructor....");
	}
	
	//Parameterised constructors....
	
	//Product p5 = new Product(500, "P" , 50);
	public Product (int productId1, String productName1 
							, double price){
		this.productId = productId1;
		this.productName = productName1;
		this.price = price;
	}
	
	//Data Hiding Design Patterns
	// using private keyword, you can achieve data hiding
	
	private int productId;
	private String productName;
	private double price;

	public static int totalNoOfRows  = 100;
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		
		this.productId = productId;
	}
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

}
