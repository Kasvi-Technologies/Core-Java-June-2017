package com.springpeople.test;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// set does not allow duplicate elements...
		//random order.......
		//the way you way inserted elements is not the same way
		//while retriveing...
		
		Set<String> strSet = new HashSet<String>();
		strSet.add("Hi");
		
		boolean flag = strSet.add("Hi");
		System.out.println(flag);
		//false means duplicate element...
		
		System.out.println(strSet.size());
		
		//TreeSet will provide soring order..
		Set<String> strSortedSet = new TreeSet<String>();
		strSortedSet.add("Aasdsadasd");
		strSortedSet.add("Zsadsadasd");
		strSortedSet.add("Psadadasd");
		strSortedSet.add("Bsfsdf");
		
		
		for (String str : strSortedSet){
			System.out.println(str);
		}
		
		
		
	}

}
