package com.springpeople.test;

//class
public class HelloWorld {

	
	private static final int count = 10;
	
	//method......
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//create numbers, integer values....
		//System.out.println(count++);
		//DataType varible = value
		int age = 1099; //upto 32 bits
		short empid = 1; //upto 16 bits
		long exp= 999; //upto 64 bits
		
		float salary = 50000.15f;  //upto 32 bits 
		double d = 54554.45;  //upto 64 bits
		
		char ch = 'A';
		boolean flag = true;
		//false
		
		String str = "My First Java application";
		
		//maain is the method, which will be executed 
		//by java application 
		//display the information..
		System.out.println("My First Java Application..");
		System.out.println("a");
		System.out.println(age +" "+salary + " " + ch + " " +str);
		
		double price = 100;
		int qty =5;
		
		//+
		//-
		//*
		// /
		//%
		double totalPrice = price * qty;
		System.out.println("Total Price:" + totalPrice);
		
		sum();
		
		int a =5;
		int b= 7;
		int sumVal = sum(a,b);
		System.out.println(sumVal);
		
	}  //main method closing....
	
	//create our own method...
	//method name is sum
	
	public static void sum(){
		System.out.println("with out parameters");
		//business logic
		int a = 10;
		int b= 100;
		int sumValue= a+b;
		System.out.println("SumValue:" + sumValue);
	}
	
	public static int sum(int a, int b){
		System.out.println("with parameters.....");
		int sumValue= a+b;
		System.out.println("SumValue:" + sumValue);
		return sumValue;
	}
	
	

}//class closing
