package com.springpeople.test;

import java.io.File;
import java.io.IOException;

public class FilesTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File file = new File("C:\\sample.txt");
		
		System.out.println(file.exists());
		
		if (! file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println(file.isDirectory());
		System.out.println(file.isFile());
		
		File file1 = new File("C:\\sample");
		file1.mkdir();
		
		file.delete();
		
	}

}
