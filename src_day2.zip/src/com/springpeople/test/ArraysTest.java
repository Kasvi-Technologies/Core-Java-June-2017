package com.springpeople.test;

import com.springpeople.beans.Product;

public class ArraysTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 5;
		int b= 10;
		int c = 100;
		int d = 89;
		
		//Array
		//you can store more than one value at the same time
		//same datatype
		
		int [] a1 = new int[5];
		a1[0] = 5;
		a1[1] =10;
		a1[2] = 50;
		a1[3] = 100;
		a1[4] = 600;
		//a1[5] = 700;  //6th location
		
		for (int index = 0; index <a1.length ; index++){
			System.out.println(a1[index]);
		}
		
		int [] b1 = {5, 6,7,8,9};
		
		Product [] p =  new Product[3];
		p[0] = new Product();
		p[1] = new Product();
		p[2] = new Product();
		
		String [] str = new String[3];
		str[0] = "Hi";
		str[1] = "sdasd";
		str[2] = "sdsad";
 		
		for (int index = 0; index <str.length ; index++){
			System.out.println(str[index]);
		}
		
		
		float [] f1 = new float[5];
		
	}

}
