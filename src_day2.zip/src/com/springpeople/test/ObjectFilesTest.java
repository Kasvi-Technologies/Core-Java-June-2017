package com.springpeople.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import com.springpeople.beans.Product;

public class ObjectFilesTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Product p = new Product(100, "", 34);
		
		//Serialization
		//writing the state of an object into the file stream..
		
		File f = new File("C:\\objectfile.ser");
		
		//
		//public class Product implements Serializable
		try {
			FileOutputStream fout = new FileOutputStream(f);
			// providing extra resposibility to run time.
			//providing extra responsibility to
			//decorator pattern
			// 
			ObjectOutputStream oout = new ObjectOutputStream(fout);
			
			oout.writeObject(p);
			
			//Serialization 
			
			//prdocut  -> serialization id
			// bytes
			//produc -> byr
			//name//
			
			FileInputStream fin = new FileInputStream(f);
			ObjectInputStream oin = new ObjectInputStream(fin);
			Product p1 = (Product) oin.readObject();
			
			System.out.println(p1.getProductName());
			System.out.println(p1.getProductId());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
	}

}
