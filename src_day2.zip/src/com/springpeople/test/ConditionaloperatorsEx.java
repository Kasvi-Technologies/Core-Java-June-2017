package com.springpeople.test;

import com.springpeople.beans.Product;
import com.springpeople.services.ProductService;



public class ConditionaloperatorsEx {

	public static void main(String[] args) {
		
		//Objects can be create using new operators..
		
		Product p = new Product();
		Product p1 = new Product();
		Product p2 = new Product();
		
		
		p.setProductId(100);
		p.setProductName("A");
		p.setPrice(10);
	//	...
		
		//Parameterised constructors....
		
		Product p5 = new Product(500, "P" , 50);
		
		
		p.totalNoOfRows = 500;
		
		p1.setProductId(200);
		p1.setProductName("B");
		p1.setPrice(20);
				
		p2.setProductId(300);
		p2.setProductName("C");
		p2.setPrice(30);
		
		System.out.println(p1.getProductId());
		System.out.println(p1.getProductName());
		System.out.println(p2.totalNoOfRows);
		
		ProductService ps = new ProductService();
		ps.addProduct(p2);
		
		
		ps.deleteProduct(100);
		
		
		System.out.println(Product.totalNoOfRows);
		
		//Static methods can't call not-static methods and 
		//non-static variables
		
		// but view versa can be possible.
		
		//i.e non-static methods can call static methods 
		//and static variables
		
		// TODO Auto-generated method stub

		int a = 75;
		
		//if is used for conditions checking...
		
		//relational operators
		
		// >   <     >=    <=
		if ( a > 100) {
			//BL
			System.out.println("inside if block");
			System.out.println("a gt 100 business logic");
		} else if (a > 50) {
			System.out.println("inside if else block");
			System.out.println("a gt 50");
		} else {
			System.out.println("inside  else block");
			System.out.println("a lt 50");
		}
		
		
		int i =0;
		while (i< 10){
			System.out.println(i);
		}
		
		//to repeat the group of statements 
		
		//while
		//for
		int count = 1;
		while (count <= 10 ) {
			//BL
			System.out.println("Count val:" + count);
			//count = count +1;
			count++;//shorthand notation
			
			//count--;  
			//count = count -1;
			
		}
		
		
		for (int count1 = 1; count1 <= 10 ; count1++){
			System.out.println("count1 from for loop:" + count1);
		}
		
		
		
		
		
	}// main method...
	
	//p , p1 and p2 lost the scope
	//these objects are automatically eligible for garbage collection
	

}
