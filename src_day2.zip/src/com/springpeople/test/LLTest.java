package com.springpeople.test;

import java.util.LinkedList;
import java.util.List;

public class LLTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> strList = new LinkedList<String>();
		
		strList.add("asdasdasdasd");
		
		for (String str : strList){
			System.out.println(str);
		}

	}

}
