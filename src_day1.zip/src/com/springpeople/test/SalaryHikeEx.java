package com.springpeople.test;

public class SalaryHikeEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double salary = 100000;
		int hike = 10;
		
		double hikeSalary = performHike(salary, hike);
		
		System.out.println("hikeSalary:"  + hikeSalary);
		
	}
	
	public static double performHike(double salary, int hike){
		return salary + (salary * hike /100);
	}

}
