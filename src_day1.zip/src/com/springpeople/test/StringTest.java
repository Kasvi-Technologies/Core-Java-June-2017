package com.springpeople.test;

import java.util.StringTokenizer;

public class StringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "Hi My First Java First Application...";
		
		String str1 = new String("Hi");
		
		int index = str.indexOf("First"); // i location in string
		System.out.println(index);
		System.out.println(str.lastIndexOf("First"));
		
		str.toLowerCase();
		
		str.toUpperCase();
		
		boolean flag = str.endsWith("sadasd");
		boolean flag1= str.startsWith("Hi");
		
		str.indexOf("Hi", 5);  
		str.length();
		
		System.out.println(str.substring(5, 10));
		if (str.equals(str1)) {
			//BL
		} else {
			//BL
		}
		
		int a = 8;
		int b = 10;
		
		if (a == b) {
			
		} else {
			
		}
		
		
		String str2 = "My First Java First application First";
		String findingStr = "First";
		
		
		//Find how many occurances that First occurs
		int index1 = 0;
		int count = 0;
		
		for (index1=0; index1 <=str2.length();) {
			int foundindex = str2.indexOf(findingStr, index1);
			if (foundindex ==-1) {
				break; // used to terminate the loop
			} 
			count++;
			System.out.println("found at " + foundindex);
			index1 = foundindex + 4;
			
		}
		
		System.out.println("total count" + count);
		//another approah....
		int count1 = 0;
		StringTokenizer st = new StringTokenizer(str2, " ");
		while (st.hasMoreTokens()){
			String token  = st.nextToken(); 
			if (token.equals(findingStr)) {
				count1++;
			}
		}
		System.out.println(count1);
		
		
		
	}

}
