package com.springpeople.services;

import com.springpeople.beans.Product;



//you can create methods for product class

//like addProduct
//deleteProduct
//updateProduct
public  class ProductService {

	public void addProduct(Product p){
		//BL to add product into database...
		System.out.println("In addProduct method...." +
							p.getProductId());
	}
	
	public void deleteProduct(int prodtId){
		//BL to delete a product from database... method...
		System.out.println("IN delete product method..."
									+ prodtId);
	}
	
	
}
