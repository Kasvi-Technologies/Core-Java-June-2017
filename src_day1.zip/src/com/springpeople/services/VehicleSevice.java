package com.springpeople.services;

//abstraction oops concept
//will specify oonly essential features with out informing
//inner details.....

//if a class contains atleast one abstract method,
//then class also should be marked as abstarct...

//An abstract class can contain abstract methods and
//non-abstract methods...
//abstract class.
public abstract class VehicleSevice{
	
	public  void drive() {
		System.out.println("VS drive method...");
	}
	
	public void asssdfsd(){
	
	}
	public void displayVehicleInfo(){
		System.out.println("Display vehicle infor from VS class");
	}
	
	//if a method does not have any implementation,
	//the you can mark it as abstract.
	//abstraction oops concept..
	
	//abstract methods should be implemented in child classes..
	public abstract String vechicleDesign();

}
