import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class DBTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//com.mysql.jdbc.Driver
		//
		//1. load the class into JVM like creating the instance
		//with out new operator
		//load and register the driver into JVM
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			//2. Obtain the database connection....
			String url = "jdbc:mysql://localhost:3306/springpeopledb";
			//jdbc:oracle:thin@localhost:3306/springpeopledb;
			
			//import java.sql 
			Connection connection = 
				DriverManager.getConnection(url, "root", "password");
			
			System.out.println(connection);
			
			String query = "create table product"
					+ "(productid int primary key, "
					+ "productname varchar(100),"
					+ "price double)";

			
			//Obtain the statement object
			//using statement objects, you can fire queries to db.
			
			Statement st = connection.createStatement();
			//st.execute(query);
			
			//insert the records...
			
			String insertQry = 
					"insert into product values(1, 'Vehicle', 456) ";
			
			String insertQry1 = 
					"insert into product values(2, 'Mobile', 23453) ";
			
			String insertQry2 = 
					"insert into product values(3, 'sdfsdf', 456) ";
			
			st.executeUpdate(insertQry);
			
			st.executeUpdate(insertQry1);
			
			st.executeUpdate(insertQry2);
			//insert, delete, update  , you can use same executeUpdatemethod..
			
			System.out.println("table created.......");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
