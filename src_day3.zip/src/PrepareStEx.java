import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;




public class PrepareStEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Class.forName("com.mysql.jdbc.Driver");
			//2. Obtain the database connection....
			String url = "jdbc:mysql://localhost:3306/springpeopledb";
			//jdbc:oracle:thin@localhost:3306/springpeopledb;
			
			//import java.sql 
			Connection connection = 
				DriverManager.getConnection(url, "root", "password");
			
			System.out.println(connection);
			
			String sql = "insert into product values (?, ?, ?)";
			PreparedStatement pst = 
							connection.prepareStatement(sql);
			
			pst.setInt(1, 10);
			pst.setString(2, "dsadads");
			pst.setDouble(3, 465546);
			
			pst.executeUpdate();
			
			pst.setInt(1, 11);
			pst.setString(2, "sadasdasdsadads");
			pst.setDouble(3, 465);
			
			pst.executeUpdate();
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
