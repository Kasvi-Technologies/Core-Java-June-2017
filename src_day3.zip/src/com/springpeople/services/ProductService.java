package com.springpeople.services;

import com.springpeople.beans.Product;
import com.springpeople.exceptions.ProductException;



//you can create methods for product class

//like addProduct
//deleteProduct
//updateProduct
public  class ProductService {

	public void addProduct(Product p){
		//BL to add product into database...
		System.out.println("In addProduct method...." +
							p.getProductId());
	}
	
	public void deleteProduct(int prodtId)
				throws ProductException {
		//BL to delete a product from database... method...
		System.out.println("IN delete product method..."
									+ prodtId);
		
		//throw keyword is used to throw user defind exceptions..
		if (prodtId < 0) {
			throw new ProductException("Product id is not valied");
		}
		
		//BL
		//BL
	}
	
	
}
