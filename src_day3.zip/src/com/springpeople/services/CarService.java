package com.springpeople.services;

//Inheritance
public class CarService extends VehicleSevice {
	
	//Method Overriding
	//Parent and child classes should have the same method signature
	public void drive() {
		System.out.println("CS drive method...");
	}
	
	//Method Overloading
	//method signature will be different....
	public void drive(int speed) {
		System.out.println("CS drive method... using " + speed);
	}

	@Override
	public String vechicleDesign() {
		System.out.println("Car releated design..............");
		// TODO Auto-generated method stub
		return "abc";
	}
	
}
