package com.springpeople.test;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.springpeople.beans.Product;

public class ListTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List list = new ArrayList();  //create a memory location
		//list
		//ArrayLIst list = new ArrayList();
		
		//add an element to list
		int a = 100;
		
		//all collections will store only objects..
		
		//Every primitive datatype java has a class, that class
		//is called wrapper claasess
		
		//int -> Integer
		//float -> Float
		//short -> Short
		//long -> Long
		
		//double -> Double
		//boolean -> Boolean
		//char  -> Char
		
		
		list.add(a);   //0th location
		//list.add(new Integer(a));
		
		list.add(200);  //1st location
		//list.add(new Integer(200)) 
		list.add("sdfsdfsdfdsfdsf");  //2nd location
		
		Product p = new Product();
		list.add(p); //3rd location
		
		Object obj = list.get(0);
		
		if (obj instanceof Integer) {
			Integer in = (Integer) obj;
			Float f1 = new Float (in.intValue());
		}
		
		if (obj instanceof Product) {
			
		}
		
		Product p1 = (Product) list.get(3);
		
//		new Float ()
		
		float f1 = (Float) list.get(1); // type casting..
		
		
		System.out.println(f1);
		
		//retrieve the Float object - > it will convert into float
		
		
		for (int i = 0; i< list.size() ; i++){
			System.out.println(list.get(i));
		}
		
	}

}
