package com.springpeople.test;

import com.springpeople.exceptions.ProductException;
import com.springpeople.services.ProductService;

public class ExceptionsTest {

	public static void main(String[] args)
					throws Exception{
		// TODO Auto-generated method stub

		System.out.println("main method starting");
		
		String s = null;
		try{
//			System.out.println("length:" + s.length());
//			//any operations on nullable object will throws
//			//the exception
//			//NullPointerException
//			
//			int a[] = new int[2];
//			a[3] = 45;//ArrayIndexOutOfBoundException
//			System.out.println("in try after exception...");
			
			ProductService ps = new ProductService();
			
			ps.deleteProduct(-1);
			
			
		} catch(ArrayIndexOutOfBoundsException ex){
			ex.printStackTrace();
			System.out.println(ex.getMessage());
		} catch(NullPointerException ex){
			ex.printStackTrace();
			System.out.println(ex.getMessage());
		}catch(ProductException ex){
			System.out.println("in exception block");
			System.out.println(ex.getMessage());
			throw ex;
			//rest of the stmts will not get executed...
		} catch(Exception ex){
			System.out.println("in exception block");
			System.out.println(ex.getMessage());
			throw ex;
			//rest of the stmts will not get executed...
		} finally {
			//this block will always gets executed
			//eventhough exception occurs
			//release the database resources
		}
		
		//when ever exception occurs , application gets terminated..
		
		System.out.println("after exception...");
		System.out.println("main method ending");
	}

}
