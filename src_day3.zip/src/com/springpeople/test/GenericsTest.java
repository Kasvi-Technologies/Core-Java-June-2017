package com.springpeople.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.springpeople.beans.Product;

public class GenericsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Generics -> collection should hold only this datatype
		List<Integer> intList = new ArrayList<Integer>();	
		
		intList.add(10);
		intList.add(100);
		intList.add(1000);
		intList.add(10000);
		intList.add(100000);
		
		//Normal for loop...
		for (int i = 0; i< intList.size(); i++) {
			System.out.println(intList.get(i));
		}
		
		intList.remove(1);
		
		intList.add(2, 300);
		
		
		//enhanced for loops...
		//Generics..
		
		for (Integer in : intList){
			System.out.println(in);
		}
		
		List<String> strList = new ArrayList<String>();
		strList.add("asdasdsad");
		
		String str = strList.get(0);
		
		
		
		List<Product> pList = new ArrayList<Product>();
		Product p = new Product(1, "sdfsa", 34);
		Product p1 = new Product(21, "sdfsa", 34);
		Product p2 = new Product(3, "sdfsa", 34);
		Product p3 = new Product(4, "sdfsa", 34);
		
		pList.add(p);
		pList.add(p1);
		pList.add(p2);
		pList.add(p3);
		
		
		for (Product product : pList) {
			System.out.println(product.getProductId() + " " +
							product.getProductName());
		}
		
		//Using iterators to repeat the collections...
		
		Iterator<Product> listItr = pList.iterator();
		
		while (listItr.hasNext()){
			Product ps = listItr.next();
			//BL....
			
		}
		
	}
	
	
	
	

}
