package com.springpeople.test;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//key should be integer
		//value should be only string
		Map<Integer, String> map = new HashMap<Integer, String>();
		
		map.put(1, "Hi");
		map.put(20, "Hi sjdhasdh");
		map.put(30, "3oth key related value");
		map.put(50, "50th key related value...");
		map.put(30, "related value");
		
		
		System.out.println(map.get(30));
		
		//Obtaining the all key elements from map....
		
		Set<Integer> keys = map.keySet();
		
		for (Integer key : keys){
			System.out.println(map.get(key));
		}
		
		//another way of retriveing the lements from map
		//no iterator...
		//entrySet() 
		
		Set<Entry<Integer, String>> entrySet = map.entrySet();
		
		for (Entry entry : entrySet){
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
		}
	
		//Key and value pair..
		Hashtable<Integer, String> ht = 
							new Hashtable<Integer,String>();
		
		//Synchronized Object  
		//Multi threaded programming
		//Synchronization
		
		
	}

}
