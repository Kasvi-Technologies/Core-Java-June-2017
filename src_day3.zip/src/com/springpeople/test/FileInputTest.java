package com.springpeople.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File file= new File("C:\\fileex1.txt");
		
		try {
			FileInputStream fin = new FileInputStream(file);
			
			byte[] b = new byte[2048];
			
			//fin.read(b);
			
			int a ;
			while ( (a = fin.read() )!= -1) {
				System.out.println( (char) a);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
