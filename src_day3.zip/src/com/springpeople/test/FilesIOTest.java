package com.springpeople.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FilesIOTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File file= new File("C:\\fileex1.txt");
		
		//write the information into file
		try {
			FileOutputStream fout = new FileOutputStream(file);
			String str = "My first files examples..";
			String str1 = "another string..";
			
			
			int i = 500;
			fout.write(str.getBytes());
			
			//fout.write("\n".getBytes()); 
			
			fout.write(str1.getBytes());
			
			fout.write((byte)i);
			
			//fout.w
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
