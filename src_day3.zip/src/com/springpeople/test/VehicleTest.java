package com.springpeople.test;

import com.springpeople.services.CarService;
import com.springpeople.services.VehicleSevice;

public class VehicleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//CarService carService = new CarService();
		//Parent class  p = new ChildClass();
		
		//polymorphism
		//single name and multiple implementations
		//Method overloading and method overriding 
		
		VehicleSevice carService = new CarService();
		
		carService.drive();
		//carService.drive(100); //
		carService.displayVehicleInfo();
		
		System.out.println(carService.vechicleDesign());
	}

}
