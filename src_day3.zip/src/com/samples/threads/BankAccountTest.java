package com.samples.threads;

public class BankAccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		BankAccount account = new BankAccount();
		
		
		WithdrawThread wt = new WithdrawThread(account);
		wt.setPriority(10);
		
		DepositThread dt = new DepositThread(account);
		dt.setPriority(5);
		
		
		wt.start();  // with draw thread will be in waiting state
		dt.start();
		//deposit the amount and call the notify
		//notify means, waiting thread will gets a chance again 
		//to execute
		
		
		try {
			dt.join();
			wt.join();
			
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("main method completed.....");
		
	}
//	In deposit emthod started......
//	In withdraw emthod started ......
//	In deposit emthod completed......
//	In withdraw emthod completed ......


}
