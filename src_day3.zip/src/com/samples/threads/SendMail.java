package com.samples.threads;

public class SendMail {
	
	public void sendMailProcess(int i){
		System.out.println("in send mail method....." + i);
		
		//BL to send a mail.....
		//
	}
	
	public static void main (String[] args){
		SendMail mail = new SendMail();
		for (int i = 0; i<10;i++) {
			System.out.println("from main method");
			mail.sendMailProcess(i);
		}
	}

}
