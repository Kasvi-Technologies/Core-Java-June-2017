package com.samples.threads;

public class MailRunnable implements Runnable{
	
	public void run (){
		SendMail mail = new SendMail();		
		for (int i = 0; i<10;i++) {
			System.out.println("from MailThread run " +
					Thread.currentThread().getName());
			try {
				Thread.sleep(100);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mail.sendMailProcess(i);
		}
	}
	
	public static void main(String [] args) {
	
		MailRunnable mr = new MailRunnable();
		Thread t = new Thread(mr, "Thread1");
		t.start();
		
		Thread t1 = new Thread(mr, "Thread2");
		t1.start();
		
		Thread t2 = new Thread(mr, "Thread3");
		t2.start();		
		
	}
	

}
