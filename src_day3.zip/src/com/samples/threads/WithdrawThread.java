package com.samples.threads;

public class WithdrawThread extends Thread{

	BankAccount bankAccount;
	
	public WithdrawThread (BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}
	public void run(){
		bankAccount.withdraw();
	}
}
