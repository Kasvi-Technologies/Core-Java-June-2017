package com.samples.threads;

public class MailThread  extends Thread {
	
	public void run (){
		SendMail mail = new SendMail();		
		for (int i = 0; i<10;i++) {
			System.out.println("from MailThread run " +
								this.getName());
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mail.sendMailProcess(i);
		}
	}
	
	public static void main (String[] args) {
		
		// start() method will internally  call the run method....
		
		MailThread mt = new MailThread();
		mt.setName("mt thread");
		mt.start();  //
		
		MailThread mt1 = new MailThread();
		mt1.setName("mt1 thread");
		mt1.start();
		
		
		MailThread mt2 = new MailThread();
		mt2.setName("mt2 thread");
		mt2.start();
		
		MailThread mt3 = new MailThread();
		mt3.setName("mt3 thread");
		mt3.start();
		
		
	}

}
