package com.samples.threads;

public class BankAccount {
	
	private int amount = -1;
	
	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public synchronized void deposit (int amount) {
		
		System.out.println("In deposit emthod started......");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//deposit bl
		this.setAmount(amount);
		notify(); //
		//the thread which is in waiting state will again start processing
		
		System.out.println("In deposit emthod completed......");
	}
	
	public synchronized void withdraw(){
		System.out.println("In withdraw emthod started ......");
		
		//bl
		
		if (amount < 0) {
			//will wait until amount deposied.....
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//this bl will be executed after notify by another thread..
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("In withdraw emthod completed ......");
	}

}
