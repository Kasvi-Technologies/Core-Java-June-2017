package com.samples.threads;

public class DepositThread extends Thread{
	
	BankAccount bankAccount;
	
	public DepositThread (BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}
	public void run(){
		
		bankAccount.deposit(1000);
	}

}
