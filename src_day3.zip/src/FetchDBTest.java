import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class FetchDBTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/springpeopledb";
			Connection connection = 
				DriverManager.getConnection(url, "root", "password");
			
			Statement st = connection.createStatement();
			
			//fetch the results......
			
			String query = "select * from product";
			
			ResultSet rs = st.executeQuery(query);
			//all database related rows information available in
			///resultset object
			
			while (rs.next()){
				int pid = rs.getInt("productid");
				String pname = rs.getString("productname");
				double price = rs.getDouble("price");
				
				System.out.println(pid + " " + pname + " " + price);
			}
			
			System.out.println(connection);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
